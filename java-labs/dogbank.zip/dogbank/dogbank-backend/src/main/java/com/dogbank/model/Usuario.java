package com.dogbank.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;

    private String cpf;

    // Outros campos, se necessário

    // Relação com Conta (opcional, para bidirecional)
    // @OneToMany(mappedBy = "usuario")
    // private List<Conta> contas;
}
